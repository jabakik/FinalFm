package com.example.finalfm.presentation.signup

import androidx.fragment.app.Fragment

class SignUpFragment: Fragment() {
}